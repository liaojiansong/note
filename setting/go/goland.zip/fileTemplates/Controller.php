<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use App\Http\Controllers\Admin\BaseController;

class ${NAME} extends BaseController
{

    public function __construct()
    {
        parent::__construct();
    }
    
    //列表
    public function index(){
    
        return view('');
    }

    //返回创建视图
    public function create()
    {
        return view('');
    }

    //保存
    public function store()
    {
       
        return redirect(request('previous_url'));
    }

    //编辑
    public function edit(${DS}id)
    {

        return view('');
    }

    //更新
    public function update(${DS}id)
    {
        return redirect(request('previous_url'));
    }

    //删除
    public function destroy(${DS}ids)
    {


        return redirect()->back();
    }

}

