<?php
#parse("PHP File Header.php")

#if (${NAMESPACE})

namespace ${NAMESPACE};

#end
use Illuminate\Database\Eloquent\BaseModel;

class ${NAME} extends BaseModel
{
    protected ${DS}table = '';
    
    protected ${DS}fillable = ['',];

}